from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30996
        DB = 'aac'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            inserted = self.database.animals.insert_one(data)  # data should be dictionary
            if inserted != 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, readData):
        if readData is not None:
            if readData:
                result = self.database.animals.find(readData, {"_id":False})
                return result
        else:
            raise Exception("Nothing to search, because search parameter is empty")

# Create method to implement the U in CRUD.
    def update(self, readData, updateData):
        if readData is not None:
            if self.database.animals.count_documents(readData, limit = 1) != 0:
                update_result = self.database.animals.update_many(readData, {"$set": updateData})
                result = update_result.raw_result
            return result
        else:
            raise Exception("Nothing to update, because data parameter is empty")

# Create method to implement the D in CRUD.
    def delete(self, readData):
        if readData is not None:
            if self.database.animals.count_documents(readData, limit = 1) != 0:
                delete_result = self.database.animals.delete_many(readData)
                result = delete_result.raw_result
            return result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")